class InvalidCoordinateError(Exception):
    pass
