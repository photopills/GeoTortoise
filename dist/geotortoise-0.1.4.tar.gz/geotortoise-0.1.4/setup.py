# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['geotortoise']

package_data = \
{'': ['*']}

install_requires = \
['Shapely>=1.8.0,<2.0.0', 'asyncpg>=0.25.0,<0.26.0', 'tortoise-orm']

setup_kwargs = {
    'name': 'geotortoise',
    'version': '0.1.4',
    'description': 'Tortoise-orm with geospatial operations ',
    'long_description': None,
    'author': 'PhotoPills Team',
    'author_email': 'it@photopills.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
